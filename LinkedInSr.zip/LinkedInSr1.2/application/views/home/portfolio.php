<h3>Portfolio</h3>
<div id="portfolioMainContent">
	<div id="portfolioDisplay" class="group">
		<div id="profilePicContainer">
			<img src="" alt="profile_picture" />
		</div>
		<div id="portfolioInfo">
			<span>[ Name ]</span><br /><br />
			<span>[ Current Residency ]</span><br /><br />
			<span>[ Location ]</span><br /><br />
			<span>[ Age ]</span><br /><br />
			<span>[ Marital Status ]</span><br /><br />
			<input type="button" id="edit" value="edit" />
		</div>
	</div>
</div>