<html>
<head>
<style>
	#menuWrapper {
		max-width: 800px;
		min-width: 775px;
		margin-top: 10px;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 10px;
		border: 1px solid black;
		padding: 5px;
		height: 75px;
	}
	
	#leftNavContainer {
		width: 200px;
		height: auto;
		float: left;
	}

	#homeButtonContainer {
		width: 180px;
		height: 25px;
		margin-top: 40px;
		padding-top:5px;
		margin-left: 5px;
		margin-right: 5px;
		border: 1px dashed grey;
		text-align: center;
	}

	#home {
		width: 100px;
	}
	
	#logoContainer {
		width: 180px;
		height: 25px;
		margin-top: 5px;
		padding-top: 5px;
		margin-left: 5px;
		margin-right: 5px;
		border: 1px dashed grey;
		text-align: center;
		float: left;
	}
	
	#rightNavContainer {
		min-width: 500px;
		height: 70px;
		margin-left: 50px;
		border: 1px dashed grey;
		float: left;
		text-align: center;
		
	}
	
	#searchButtonContainer {
		margin-left: 20px;
		margin-right: 20px;
		padding-top: 5px;
	}
	
	#searchButton {
		width: 300px;
		height: 20px;
	}
	
	#buttons {
		margin-left: 20px;
		margin-right: 20px;
		border: 1px dashed grey;
		margin-top: 10px;
		padding-top: 5px;
		padding-bottom: 5px;
	}
	
	.menuButtons {
		width: 100px;
		margin-left: 5px;
		margin-right: 5px;
	}
	
	.group:before,
		.group:after {
   		content: "";
    	display: table;
	} 
	
	.group:after {
    	clear: both;
	}
	.group {
    	zoom: 1; /* For IE 6/7 (trigger hasLayout) */
	}
	
	#portfolioMainContent {
		max-width: 800px;
		min-width: 700px;
		margin-top: 10px;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 10px;
		border: 1px solid black
	}
	
	#portfolioDisplay {
		max-width: 600px;
		min-width: 400px;
		margin-top: 5px;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 5px;
		border: 1px dashed grey;
	}
	
	#profilePicContainer {
		width: 250px;
		height: 250px;
		text-align: center;
		vertical-align: center;
		border: 1px dashed grey;
		margin: 5px 5px 5px 5px;
		float: left;
	}
	
	#portfolioInfo {
		width: auto;
		height: auto;
		border: 1px dashed grey;
		margin: 5px 5px 5px 5px;
		float: left;
	}
	
</style>
<!-- <script type="text/javascript" >  -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js" type="text/javascript"></script>
</head>