<body>
<div id="menuWrapper" class="group">
	<div id="leftNavContainer">
		<div id="logoContainer">
			<img src="" alt="company_logo" ></img>
		</div>
		<div id="homeButtonContainer">
			<button type="button" id="home" value="Home">Home</button>
		</div>
	</div>
	<div id="rightNavContainer">
		<div id="searchButtonContainer">
			<button type="button" id="searchButton">Search / Filter Results...</button>
		</div>
		<div id="buttons">
			<button type="button" class="menuButtons" id="loginButton" value="login">Login</button>
			<button type="button" class="menuButtons" id="registerButton" value="register">Register</button>
			<button type="button" class="menuButtons" id="profileButton">Profile</button>
			<button type="button" class="menuButtons" id="messageButton">Messages(?)</button>
<!-- 			<button type="button" class="menuButtons" id="">[ etc.. ]</button> -->
		</div>
	</div>	
</div>
<!-- </body> -->
<script>
 	$(document).ready(function(){
 	
 		$('#loginButton').click( function() {
			window.location = "/ci/index.php/login/authenticate";
		});
		
		$('#registerButton').click( function() {
			window.location = "/ci/index.php/register/create";
		});
		
		$('#profileButton').click( function() {
			window.location = "/ci/index.php/home/portfolio";
		});
 	});
</script>
