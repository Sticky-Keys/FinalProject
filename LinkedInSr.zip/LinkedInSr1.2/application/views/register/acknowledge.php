<?php 
	echo "Thank you for completing your user profile";
	?>