<?php
echo "User Profile creation successful!!";

//add buttons to return to main page or etc..