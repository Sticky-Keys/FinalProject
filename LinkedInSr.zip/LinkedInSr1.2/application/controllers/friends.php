<?php
class friends extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('friends_model');
		$this->load->helper('url_helper');

	}
	
	public function index()
	{
		
	}
	
	public function viewFriends()
	{
	
	}
	
	public function addFriend()
	{
	
	}	
}