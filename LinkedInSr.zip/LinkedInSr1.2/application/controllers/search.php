<?php
class Search extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('search_model');
		$this->load->helper('url_helper');

	}
	
	public function index()
	{
	
	}
	
	public function search()
	{
	
	}
	
	public function result()
	{
	
	}	
}