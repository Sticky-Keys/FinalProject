<?php
class Favorites extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('favorites_model');
		$this->load->helper('url_helper');

	}
	
	public function index()
	{
	
	}
	
	public function displayFavorites()
	{
	
	}
	
	public function addFavorites( $string, $int )
	{
	
	}
	
	public function editFavorite( $string, $string, $string )
	{
	
	}
		
}