<?php
class Profile extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('profile_model');
		$this->load->helper('url_helper');

	}
	
	public function index()
	{
	
	}
	
	public function viewUser( $user_id ) 
	{
	
	}
	
	public function owner()
	{
	
	}
	
	public function viewCommunity()
	{
	
	}
	
	public function communityOwner()
	{
	
	}
		
}